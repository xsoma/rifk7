#pragma once

class c_hooks
{
public:
	static void run();
};

void reflection_creation();
