#pragma once

extern const unsigned char cod[3012];
extern const unsigned char doublekill[37558];
extern const unsigned char headshot[2827];
extern const unsigned char rifk[102600];
extern const unsigned char quadkill[143452];
extern const unsigned char quake[6120];
extern const unsigned char roblox[15114];
extern const unsigned char triplekill[80652];
extern const unsigned char uff[5894];
extern const unsigned char unreal[12246];
extern const unsigned char wicked[111338];

inline bool radio_muted = false;

void playback_loop();
