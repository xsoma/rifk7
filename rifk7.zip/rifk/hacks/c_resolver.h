#pragma once

#include "c_animation_system.h"
#include "../sdk/c_game_event_manager.h"

class c_resolver
{
public:
	struct resolver_infos
	{

		bool jitter_desync = false, high_delta = false, low_delta = false, static_desync = false, lby_changed = false;

		float last_lby = FLT_MAX, lby_delta = FLT_MAX, last_eyes = FLT_MAX, eye_delta = FLT_MAX, eye_lby_delta = FLT_MAX, eyes = FLT_MAX;

	};
	struct resolverInfo
	{
	public:
		float fakegoalfeetyaw;
		resolver_infos current_tick;
		resolver_infos previous_tick;

	};

	bool has_target;

	c_qangle last_aim_angle;
	c_qangle last_eye_pos;
	matrix3x4 last_bones[128];
	c_cs_player::hitbox last_hitbox;

	int last_shot_missed_index;
	int missed_due_to_spread[65];
	int missed_due_to_bad_resolve[65];
	int resolver_method[65];
	int base_weight[65];
	int base_prev_weight[65];
	int cycle_difference[65];
	static void resolve2(c_animation_system::animation* record);
	static bool get_target_freestand_yaw(c_cs_player* target, float* yaw);
	static void on_player_hurt(c_game_event* event);
	static void on_bullet_impact(c_game_event* event);
	static void on_round_start(c_game_event* event);
	void on_player_death(c_game_event* event);
	inline static resolverInfo __player[64];
	inline static resolverInfo resolverinfoo;

private:

}; extern c_resolver resolver;
