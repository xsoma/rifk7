#include "c_resolver.h"
#include "../utils/math.h"
#include "c_aimhelper.h"
#include "c_trace_system.h"
#include "../sdk/c_client_entity_list.h"
#include <random>
#include "c_esp.h"
#include "../sdk/c_weapon_system.h"
#include <d3dx9.h>
c_resolver resolver;

void c_resolver::resolve2(c_animation_system::animation* record)
{
	float resolver_yaw = 0.f;

	// is it neither a bot nor a legit player?
	if (!record->player || record->player->get_info().fakeplayer)
	{
		resolver.missed_due_to_bad_resolve[record->index] = 0;
		return;
	}

	const auto animstate = record->anim_state;

	if (!record->has_anim_state)
		return;

	const auto missed_shots = resolver.missed_due_to_bad_resolve[record->index];

	auto logic_resolver_1 = [&]() // rifk7 resolver with changes
	{
		const auto local = c_cs_player::get_local_player();

		if (!local)
			return 0.f;

		auto resolver_yaw = 0.f;
		auto freestanding_yaw = 0.f;

		const auto current_shot = missed_shots % 2;
		float max_desync_angle = 29.f;

		const auto plus_desync = record->eye_angles.y + max_desync_angle;
		const auto minus_desync = record->eye_angles.y - max_desync_angle;

		get_target_freestand_yaw(local, &freestanding_yaw);

		const auto diff_from_plus_desync = fabs(math::angle_diff(freestanding_yaw, plus_desync));
		const auto diff_from_minus_desync = fabs(math::angle_diff(freestanding_yaw, minus_desync));

		const auto first_yaw = diff_from_plus_desync < diff_from_minus_desync ? plus_desync : minus_desync;
		const auto second_yaw = diff_from_plus_desync < diff_from_minus_desync ? minus_desync : plus_desync;
		const auto third_yaw = math::calc_angle(local->get_shoot_position(), record->player->get_shoot_position()).y;

		switch (current_shot)
		{
		case 0:
			resolver_yaw = first_yaw;
			break;
		case 1:
			resolver_yaw = second_yaw;
			break;
		case 2:
			resolver_yaw = third_yaw;
			break;
		default:
			break;
		}

		return resolver_yaw;
	};

	resolver_yaw = logic_resolver_1();

	logging->info(_("resolver delta = %f\n", resolver_yaw));

	record->anim_state.goal_feet_yaw = math::normalize_yaw(resolver_yaw);

	const auto current_animstate = record->player->get_anim_state();

	if (current_animstate)
		current_animstate->goal_feet_yaw = record->anim_state.goal_feet_yaw;


}

void c_resolver::on_player_hurt(c_game_event* event) //
{
	if (!event || !config.rage.enabled)
		return;

	auto local = c_cs_player::get_local_player();

	if (!local || !local->is_alive())
		return;

	const auto attacker = client_entity_list()->get_client_entity(
		engine_client()->get_player_for_user_id(event->get_int(_("attacker"))));

	const auto target = reinterpret_cast<c_cs_player*>(client_entity_list()->get_client_entity(
		engine_client()->get_player_for_user_id(event->get_int(_("userid")))));

	if (attacker && target && attacker == local && target->is_enemy())
	{
		static const auto hit_msg = __("Hit %s in %s for %d damage");
		_rt(hit, hit_msg);
		char msg[255];

		const auto hitgroup = event->get_int("hitgroup");
		const auto dmg = event->get_int("dmg_health");

		switch (hitgroup)
		{
		case hitgroup_head:
			sprintf_s(msg, hit, target->get_info().name, _("head"), dmg);
			break;
		case hitgroup_leftleg:
		case hitgroup_rightleg:
			sprintf_s(msg, hit, target->get_info().name, _("leg"), dmg);
			break;
		case hitgroup_stomach:
			sprintf_s(msg, hit, target->get_info().name, _("stomach"), dmg);
			break;
		default:
			sprintf_s(msg, hit, target->get_info().name, _("body"), dmg);
			break;
		}

		logging->info(msg);

		int index = target->index();
		resolver.missed_due_to_bad_resolve[index]--;
		resolver.missed_due_to_bad_resolve[index] =
			std::clamp(resolver.missed_due_to_bad_resolve[index], 0, 99);
	}

}

void c_resolver::on_bullet_impact(c_game_event* event)//
{
	if (!event || !config.rage.enabled)
		return;

	auto local = c_cs_player::get_local_player();

	if (!local || !local->is_alive())
		return;

	const auto target = reinterpret_cast<c_cs_player*>(client_entity_list()->get_client_entity(engine_client()->get_player_for_user_id(event->get_int(_("userid")))));

	if (!target || target != local)
		return;

	c_vector3d pos(event->get_float(_("x")), event->get_float(_("y")), event->get_float(_("z")));

	// this can still be improved by a lot.
	// it doesnt account for the delay between the server, client and such.
	auto missed_due_to_spread = [&](c_vector3d pos)
	{
		c_vector3d aim_eye_pos = resolver.last_eye_pos;
		c_qangle impact_angle = math::calc_angle(aim_eye_pos, pos);

		c_vector3d forward, right, up, new_angle, end;
		math::angle_vectors(impact_angle, forward, right, up);
		math::vector_angles(forward, new_angle);

		// calculate end point of trace.
		math::angle_vectors(new_angle, end);

		if (resolver.last_shot_missed_index > 0)
		{
			
		}
		resolver.last_shot_missed_index = 0;
	};
	missed_due_to_spread(pos);
}

void c_resolver::on_round_start(c_game_event* event)//
{
	resolver.last_shot_missed_index = 0;
	resolver.has_target = false;

	std::fill(resolver.missed_due_to_bad_resolve, resolver.missed_due_to_bad_resolve +
		ARRAYSIZE(resolver.missed_due_to_bad_resolve), 0);

	std::fill(resolver.missed_due_to_spread, resolver.missed_due_to_spread +
		ARRAYSIZE(resolver.missed_due_to_spread), 0);
}

void c_resolver::on_player_death(c_game_event* event)//
{
	if (!event || !config.rage.enabled)
		return;

	auto local = c_cs_player::get_local_player();

	if (!local || !local->is_alive())
	{
		resolver.last_shot_missed_index = 0;
		return;
	}

	int victim_id = event->get_int(_("userid"));
	int killer_id = event->get_int(_("attacker"));

	bool is_headshot = event->get_int(_("headshot"));

	int victim_index = engine_client()->get_player_for_user_id(victim_id);
	int killer_index = engine_client()->get_player_for_user_id(killer_id);

	if (victim_index && killer_index && local)
	{
		resolver.missed_due_to_bad_resolve[victim_index] = 0;
		resolver.missed_due_to_spread[victim_index] = 0;
	}
}

bool c_resolver::get_target_freestand_yaw(c_cs_player* target, float* yaw)
{
	float dmg_left = 0.f;
	float dmg_right = 0.f;

	static auto get_rotated_pos = [](c_vector3d start, float rotation, float distance)
	{
		float rad = deg2rad(rotation);
		start.x += cos(rad) * distance;
		start.y += sin(rad) * distance;

		return start;
	};

	const auto local = c_cs_player::get_local_player();

	if (!local || !target || !local->is_alive())
		return false;

	c_vector3d local_eye_pos = local->get_shoot_position();
	c_vector3d eye_pos = target->get_shoot_position();
	c_qangle angle = math::calc_angle(local_eye_pos, eye_pos);

	auto backwards = angle.y;

	c_vector3d pos_left = get_rotated_pos(eye_pos, angle.y + 90.f, 40.f);
	c_vector3d pos_right = get_rotated_pos(eye_pos, angle.y + 90.f, -40.f);

	const auto wall_left = trace_system->wall_penetration(local_eye_pos, pos_left,
		nullptr, local);

	const auto wall_right = trace_system->wall_penetration(local_eye_pos, pos_right,
		nullptr, local);

	if (wall_left.has_value())
		dmg_left = wall_left.value().damage;

	if (wall_right.has_value())
		dmg_right = wall_right.value().damage;

	// we can hit both sides, lets force backwards
	if (fabsf(dmg_left - dmg_right) < 10.f)
	{
		*yaw = backwards;
		return false;
	}

	bool direction = dmg_left > dmg_right;
	*yaw = direction ? angle.y - 90.f : angle.y + 90.f;

	return true;
}

/*&
void c_resolver::resolve_shot(resolver::shot& shot)
{
	if (!config.rage.enabled || shot.manual)
		return;

	const auto player = reinterpret_cast<c_cs_player*>(client_entity_list()->get_client_entity(shot.record.index));

	if (player != shot.record.player)
		return;

	const auto hdr = model_info_client()->get_studio_model(shot.record.player->get_model());

	if (!hdr)
		return;

	const auto info = animation_system->get_animation_info(player);

	if (!info)
		return;

	const auto angle = math::calc_angle(shot.start, shot.server_info.impacts.back());
	c_vector3d forward;
	math::angle_vectors(angle, forward);
	const auto end = shot.server_info.impacts.back() + forward * 2000.f;
	const auto spread_miss = !c_aimhelper::can_hit_hitbox(shot.start, end, &shot.record, hdr, shot.hitbox);

	if (shot.server_info.damage > 0)
	{
		static const auto hit_msg = __("Hit %s in %s for %d damage.");
		_rt(hit, hit_msg);
		char msg[255];
		switch (shot.server_info.hitgroup)
		{
		case hitgroup_head:
			sprintf_s(msg, hit, player->get_info().name, _("head"), shot.server_info.damage);
			break;
		case hitgroup_leftleg:
		case hitgroup_rightleg:
			sprintf_s(msg, hit, player->get_info().name, _("leg"), shot.server_info.damage);
			break;
		case hitgroup_stomach:
			sprintf_s(msg, hit, player->get_info().name, _("stomach"), shot.server_info.damage);
			break;
		default:
			sprintf_s(msg, hit, player->get_info().name, _("body"), shot.server_info.damage);
			break;
		}
		logging->info(msg);
	}
	else if (spread_miss)
	{
		logging->info(_("Missed shot due to spread."));
		++info->missed_due_to_spread;
	}
	else if (!spread_miss) {

		logging->info(_("Missed shot due to brute angle."));
		++info->missed_due_to_spread;

	}

	if (!shot.record.player->is_alive() || shot.record.player->get_info().fakeplayer
		|| !shot.record.has_anim_state || !shot.record.player->get_anim_state() || !info)
		return;

	// note old brute_yaw.
	const auto old_brute_yaw = info->brute_yaw;

	// check deviation from server.
	auto backup = c_animation_system::animation(shot.record.player);
	shot.record.apply(player);
	const auto trace = trace_system->wall_penetration(shot.start, end, &shot.record);
	auto does_match = (trace.has_value() && trace.value().hitgroup == shot.server_info.hitgroup)
		|| (!trace.has_value() && spread_miss);

	const auto  lby = shot.record.player->get_lby();

	if (!does_match || c_cs_player::on_ground)
	{

		if (lby > 25)
		{

			switch (info->brute_state)
			{
			case resolver_start:
				info->brute_state = resolver_inverse;
				info->brute_yaw = +58.f;
				logging->debug("BRUTE STAGE 1: + 58.f");
				break;
			case resolver_inverse:
				info->brute_state = resolver_no_desync;
				logging->debug("BRUTE STAGE 2: + 37.f");
				info->brute_yaw = +37.f;
				break;
			case resolver_no_desync:
				info->brute_state = resolver_start;
				logging->debug("BRUTE STAGE 3: + 24.f");
				info->brute_yaw = +24.f;
				break;
			}
			//resolve = +
		}

		if (lby < 25)
		{

			switch (info->brute_state)
			{
			case resolver_start:
				info->brute_state = resolver_inverse;
				info->brute_yaw = -58.f;
				logging->debug("BRUTE STAGE 1: - 58.f");
				break;
			case resolver_inverse:
				info->brute_state = resolver_no_desync;
				logging->debug("BRUTE STAGE 2: - 37.f");
				info->brute_yaw = -37.f;
				break;
			case resolver_no_desync:
				info->brute_state = resolver_start;
				logging->debug("BRUTE STAGE 3: - 24.f");
				info->brute_yaw = -24.f;
				break;
			}
			//resolve = -
		}
	}

	player->get_anim_state()->goal_feet_yaw = math::normalize_yaw(player->get_anim_state()->goal_feet_yaw + info->brute_yaw);

	// apply changes.
	if (!info->frames.empty())
	{
		c_animation_system::animation* previous = nullptr;

		// jump back to the beginning.
		*player->get_anim_state() = info->frames.back().anim_state;

		for (auto it = info->frames.rbegin(); it != info->frames.rend(); ++it)
		{
			auto& frame = *it;
			const auto frame_player = reinterpret_cast<c_cs_player*>(
				client_entity_list()->get_client_entity(frame.index));

			if (frame_player == frame.player
				&& frame.player == player)
			{
				// re-run complete animation code and repredict all animations in between!
				frame.anim_state = *player->get_anim_state();
				frame.apply(player);
				player->get_flags() = frame.flags;
				*player->get_animation_layers() = frame.layers;
				player->get_simtime() = frame.sim_time;

				info->update_animations(&frame, previous);
				frame.abs_ang.y = player->get_anim_state()->goal_feet_yaw;
				frame.flags = player->get_flags();
				*player->get_animation_layers() = frame.layers;
				frame.build_server_bones(player);
				previous = &frame;
			}
		}
	}
}

void c_resolver::register_shot(resolver::shot&& s)
{
	shots.emplace_front(std::move(s));
}

void c_resolver::on_player_hurt(c_game_event* event)
{
	const auto attacker = event->get_int(_("attacker"));
	const auto attacker_index = engine_client()->get_player_for_user_id(attacker);

	if (attacker_index != engine_client()->get_local_player())
		return;

	if (shots.empty())
		return;

	resolver::shot* last_confirmed = nullptr;

	for (auto it = shots.rbegin(); it != shots.rend(); it = next(it))
	{
		if (it->confirmed && !it->skip)
		{
			last_confirmed = &*it;
			break;
		}
	}

	if (!last_confirmed)
		return;

	const auto userid = event->get_int(_("userid"));
	const auto index = engine_client()->get_player_for_user_id(userid);

	if (index != last_confirmed->record.index)
		return;

	last_confirmed->server_info.index = index;
	last_confirmed->server_info.damage = event->get_int(_("dmg_health"));
	last_confirmed->server_info.hitgroup = event->get_int(_("hitgroup"));
}

void c_resolver::on_bullet_impact(c_game_event* event)
{
	const auto userid = event->get_int(_("userid"));
	const auto index = engine_client()->get_player_for_user_id(userid);

	if (index != engine_client()->get_local_player())
		return;

	if (shots.empty())
		return;

	resolver::shot* last_confirmed = nullptr;

	for (auto it = shots.rbegin(); it != shots.rend(); it = next(it))
	{
		if (it->confirmed && !it->skip)
		{
			last_confirmed = &*it;
			break;
		}
	}

	if (!last_confirmed)
		return;

	last_confirmed->impacted = true;
	last_confirmed->server_info.impacts.emplace_back(event->get_float(_("x")),
		event->get_float(_("y")),
		event->get_float(_("z")));
}

void c_resolver::on_weapon_fire(c_game_event* event)
{
	const auto userid = event->get_int(_("userid"));
	const auto index = engine_client()->get_player_for_user_id(userid);

	if (index != engine_client()->get_local_player())
		return;

	if (shots.empty())
		return;

	resolver::shot* last_unconfirmed = nullptr;

	for (auto it = shots.rbegin(); it != shots.rend(); it = next(it))
	{
		if (!it->confirmed)
		{
			last_unconfirmed = &*it;
			break;
		}

		it->skip = true;
	}

	if (!last_unconfirmed)
		return;

	last_unconfirmed->confirmed = true;
}

void c_resolver::on_render_start()
{
	for (auto it = shots.begin(); it != shots.end();)
	{
		if (it->time + 1.f < global_vars_base->curtime)
			it = shots.erase(it);
		else
			it = next(it);
	}

	for (auto it = shots.begin(); it != shots.end();)
	{
		if (it->confirmed && it->impacted)
		{
			resolve_shot(*it);
			c_esp::draw_local_impact(it->start, it->server_info.impacts.back());
			it = shots.erase(it);
		}
		else
			it = next(it);
	}
}*/

