#pragma once
#include "../includes.h"

class c_legitbot
{
public:
	static void aim(c_user_cmd* cmd);
	static void backtrack(c_cs_player* local, c_user_cmd* cmd);
private:
};
