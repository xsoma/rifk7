#pragma once

#include "macros.h"

class c_engine_sound
{

};

interface_var(c_engine_sound, engine_sound, "engine.dll", "IEngineSoundClient")
