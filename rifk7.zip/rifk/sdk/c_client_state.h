#pragma once

#include <cstdint>
#include "c_net_channel.h"
#include "c_vector3d.h"
#include "../utils/c_memory.h"

class c_event_info;

class c_net_graph_system {
public:
	static c_net_graph_system* get();
};

class c_client_state {
	

public:
	static c_client_state* get()
	{
		static const auto state = **reinterpret_cast<c_client_state***>(sig("engine.dll", "8B 3D ? ? ? ? 8A F9") + 2);
		return state;
	}
	std::byte pad0[0x9C]; //0x0000
	c_net_channel* net_channel; //0x009C
	int iChallengeNr; //0x00A0
	std::byte pad1[0x64]; //0x00A4
	int iSignonState; //0x0108
	std::byte pad2[0x8]; //0x010C
	float flNextCmdTime; //0x0114
	int iServerCount; //0x0118
	int iCurrentSequence; //0x011C
	char _0x0120[4];
	__int32 m_iClockDriftMgr; //0x0124
	char _0x0128[68];
	__int32 m_iServerTick; //0x016C
	__int32 m_iClientTick; //0x0170
	int iDeltaTick; //0x0174
	bool bPaused; //0x0178
	std::byte pad4[0x7]; //0x0179
	int iViewEntity; //0x0180
	int iPlayerSlot; //0x0184
	char szLevelName[260]; //0x0188
	char szLevelNameShort[80]; //0x028C
	char szGroupName[80]; //0x02DC
	std::byte pad5[0x5C]; //0x032C
	int iMaxClients; //0x0388
	std::byte pad6[0x4984]; //0x038C
	float flLastServerTickTime; //0x4D10
	bool bInSimulation; //0x4D14
	std::byte pad7[0xB]; //0x4D15
	int iOldTickcount; //0x4D18
	float flTickRemainder; //0x4D1C
	float flFrameTime; //0x4D20
	int nLastOutgoingCommand; //0x4D38
	int choked_commands; //0x4D30
	int nLastCommandAck; //0x4D2C
	int iCommandAck; //0x4D30
	int iSoundSequence; //0x4D34
	std::byte pad8[0x50]; //0x4D38
	c_vector3d viewangles; //0x4D88
	std::byte pad9[0xD0]; //0x4D9A 
	c_event_info* m_events;
};

#define client_state c_client_state::get()
#define net_graph c_net_graph_system::get()

#define net_channel client_state->net_channel
