#pragma once

#include "macros.h"

class c_surface
{
public:
	vfunc(66, unlock_cursor(), void(__thiscall*)(c_surface*))()
};

interface_var(c_surface, surface, "vguimatsurface.dll", "VGUI_Surface")
